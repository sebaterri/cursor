# intentionally-buggy-express-app

npm install

npm start (to start nodemon)