# intentionally buggy react app

this is built with create-react-app

you may need yarn to start?

if not, just <code>npm start</code>