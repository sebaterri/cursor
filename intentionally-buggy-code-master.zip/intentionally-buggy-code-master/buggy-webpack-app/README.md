# intentionally-buggy-webpack-app

npm install

npm start (to start local webpack dev server)

or 

npm build